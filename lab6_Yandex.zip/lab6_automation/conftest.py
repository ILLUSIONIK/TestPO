"""Shared pytest fixtures and failure screenshots."""

import os
from pathlib import Path

import pytest
from selenium import webdriver
from selenium.webdriver.chrome.options import Options


@pytest.fixture
def browser():
    options = Options()
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--window-size=1920,1080")
    options.add_argument("--disable-notifications")
    if os.getenv("HEADLESS", "1").lower() not in {"0", "false", "no"}:
        options.add_argument("--headless=new")
    binary = os.getenv("CHROME_BINARY")
    if binary:
        options.binary_location = binary

    driver = webdriver.Chrome(options=options)  # Selenium Manager resolves the driver.
    driver.implicitly_wait(0)  # Explicit waits are used in Page Objects.
    yield driver
    driver.quit()


@pytest.fixture
def base_url():
    return os.getenv("BASE_URL", "https://ya.ru")


def pytest_runtest_makereport(item, call):
    """Attach a screenshot to Allure and save a copy when a test fails."""
    if call.when != "call" or call.excinfo is None:
        return
    driver = item.funcargs.get("browser")
    if not driver:
        return
    try:
        screenshot = driver.get_screenshot_as_png()
        try:
            import allure
            allure.attach(
                screenshot,
                name=f"failure-{item.name}",
                attachment_type=allure.attachment_type.PNG,
            )
        except ImportError:
            pass
        output_dir = Path("screenshots")
        output_dir.mkdir(exist_ok=True)
        safe_name = "".join(ch if ch.isalnum() or ch in "-_." else "_" for ch in item.name)
        (output_dir / f"failure-{safe_name}.png").write_bytes(screenshot)
    except Exception:
        # A screenshot must not hide the original test failure.
        pass
