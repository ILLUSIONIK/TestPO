"""Общие фикстуры Selenium и сохранение скриншотов тестов."""

import os
from pathlib import Path

import pytest
from selenium import webdriver
from selenium.webdriver.chrome.options import Options


@pytest.fixture
def browser():
    options = Options()
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--window-size=1920,1080")
    options.add_argument("--disable-notifications")

    # По умолчанию открывается видимое окно Chrome,
    # чтобы CAPTCHA можно было решить вручную.
    headless = os.getenv("HEADLESS", "0").lower()
    if headless not in {"0", "false", "no"}:
        options.add_argument("--headless=new")

    # Если Chrome установлен не в стандартном месте,
    # путь можно передать через переменную CHROME_BINARY.
    chrome_binary = os.getenv("CHROME_BINARY")
    if chrome_binary:
        options.binary_location = chrome_binary

    # Selenium Manager автоматически подбирает драйвер браузера.
    driver = webdriver.Chrome(options=options)
    driver.implicitly_wait(0)

    yield driver

    driver.quit()


@pytest.fixture
def base_url():
    """Адрес сайта для тестов."""
    return os.getenv("BASE_URL", "https://ya.ru")


def pytest_runtest_makereport(item, call):
    """Сохраняет скриншот после каждого UI-теста и прикладывает его к Allure."""
    # Скриншот делаем после выполнения теста, пока браузер ещё открыт.
    if call.when != "call":
        return

    driver = item.funcargs.get("browser")
    if driver is None:
        return

    status = "failed" if call.excinfo is not None else "passed"

    try:
        screenshot = driver.get_screenshot_as_png()

        screenshots_dir = Path("screenshots")
        screenshots_dir.mkdir(parents=True, exist_ok=True)

        safe_test_name = "".join(
            char if char.isalnum() or char in "-_." else "_"
            for char in item.name
        )

        screenshot_name = f"{status}-{safe_test_name}.png"
        screenshot_path = screenshots_dir / screenshot_name
        screenshot_path.write_bytes(screenshot)

        # Если подключён allure-pytest, скриншот появится и в Allure.
        try:
            import allure

            allure.attach(
                screenshot,
                name=f"{status}-{item.name}",
                attachment_type=allure.attachment_type.PNG,
            )
        except Exception:
            # Отсутствие Allure не должно мешать запуску или сохранению PNG.
            pass

    except Exception:
        # Ошибка сохранения скриншота не должна скрывать результат теста.
        pass