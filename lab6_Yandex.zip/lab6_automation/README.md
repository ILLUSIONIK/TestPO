# Лабораторная работа № 6

Автоматизация проверки поиска на сайте Яндекс с Selenium WebDriver, pytest, Page Object Model и Allure.

## Что проверяется

- поиск по трём запросам и наличие ожидаемого слова в первом результате;
- отображение подсказок при вводе запроса;
- очистка строки поиска;
- скриншот при падении теста (прикладывается к Allure и сохраняется в `screenshots/`).

## Структура проекта

```text
lab6_automation/
├── pages/                  # Page Object
├── tests/                  # тестовые сценарии
├── screenshots/            # скриншоты ошибок
├── conftest.py             # фикстуры Selenium и скриншоты
├── pytest.ini              # маркеры pytest
└── requirements.txt        # зависимости
```

## Установка

Нужны Python 3.8+ и Google Chrome или Chromium. Selenium Manager автоматически подбирает драйвер.

### Windows (PowerShell)

```powershell
cd lab6_automation
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
```

### Linux / macOS

```bash
cd lab6_automation
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

## Запуск

```bash
# Последовательный запуск
pytest tests/test_yandex_form.py -v

# Параллельно в двух процессах
pytest tests/test_yandex_form.py -n 2 -v

# Сбор результатов Allure
pytest tests/test_yandex_form.py --alluredir=allure-results -v
```

По умолчанию браузер запускается в headless-режиме. Для показа окна задайте `HEADLESS=0`.
Если Chromium установлен нестандартно, укажите путь в `CHROME_BINARY`.

PowerShell:

```powershell
$env:HEADLESS = "0"
$env:CHROME_BINARY = "C:\Program Files\Google\Chrome\Application\chrome.exe"
pytest tests/test_yandex_form.py -v
```

Для HTML-отчёта установите Allure Commandline отдельно, затем выполните:

```bash
allure serve allure-results
# или сохранить статический отчёт:
allure generate allure-results -o allure-report --clean
```

## Примечание

Поисковая выдача меняется со временем и зависит от региона, поэтому проверка ожидаемого слова может потребовать обновления. CAPTCHA, сетевые ограничения или недоступность Яндекса также могут помешать UI-тестам. Запуск в headless-режиме установлен по умолчанию; Chromium/Chrome должен быть установлен локально.
