"""Page Object для формы поиска Яндекса."""

from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait


class YandexFormPage:
    SEARCH_INPUT = (By.ID, "text")
    SEARCH_RESULTS = (By.CSS_SELECTOR, "#search-result .serp-item")
    FIRST_RESULT = (By.CSS_SELECTOR, "#search-result .serp-item")
    SUGGESTIONS = (
        By.CSS_SELECTOR,
        ".mini-suggest__popup-content, [role='listbox']",
    )

    def __init__(self, driver, timeout=15):
        self.driver = driver
        self.timeout = timeout
        self.wait = WebDriverWait(driver, timeout)

    def _captcha_is_visible(self):
        """Проверяет, показывает ли Яндекс страницу CAPTCHA."""
        page = self.driver.page_source.casefold()
        url = self.driver.current_url.casefold()

        captcha_text = (
            "подтвердите, что запросы",
            "я не робот",
            "smartcaptcha",
            "showcaptcha",
        )

        return (
            any(marker in page for marker in captcha_text)
            or "captcha" in url
        )

    def _wait_for_manual_captcha(self):
        """Ожидает, пока пользователь вручную решит CAPTCHA в Chrome."""
        input(
            "\nЯндекс показал CAPTCHA. Реши её в окне Chrome, "
            "затем вернись в терминал и нажми Enter..."
        )

    def open_page(self, url):
        """Открывает Яндекс и при необходимости ждёт ручного решения CAPTCHA."""
        self.driver.get(url)

        try:
            WebDriverWait(self.driver, self.timeout).until(
                lambda driver: (
                    driver.find_elements(*self.SEARCH_INPUT)
                    or self._captcha_is_visible()
                )
            )
        except TimeoutException:
            pass

        if self._captcha_is_visible():
            self._wait_for_manual_captcha()

        self.wait.until(EC.presence_of_element_located(self.SEARCH_INPUT))
        return self

    def enter_search_text(self, text):
        field = self.wait.until(
            EC.element_to_be_clickable(self.SEARCH_INPUT)
        )
        field.clear()
        field.send_keys(text)
        return self

    def wait_for_suggest(self):
        self.wait.until(
            EC.visibility_of_element_located(self.SUGGESTIONS)
        )
        return self

    def submit_search(self):
        field = self.wait.until(
            EC.element_to_be_clickable(self.SEARCH_INPUT)
        )
        field.send_keys(Keys.ENTER)
        return self

    def wait_for_search_results(self):
        """Ждёт результаты поиска или ручное решение CAPTCHA."""
        try:
            WebDriverWait(self.driver, 25).until(
                lambda driver: (
                    driver.find_elements(*self.SEARCH_RESULTS)
                    or self._captcha_is_visible()
                )
            )
        except TimeoutException:
            pass

        if self._captcha_is_visible():
            self._wait_for_manual_captcha()

        WebDriverWait(self.driver, 45).until(
            EC.presence_of_element_located(self.SEARCH_RESULTS)
        )
        return self

    def get_first_result_text(self):
        result = self.wait.until(
            EC.visibility_of_element_located(self.FIRST_RESULT)
        )
        return result.text.strip()

    def get_search_value(self):
        field = self.wait.until(
            EC.presence_of_element_located(self.SEARCH_INPUT)
        )
        return field.get_attribute("value") or ""

    def clear_search_field(self):
        field = self.wait.until(
            EC.element_to_be_clickable(self.SEARCH_INPUT)
        )
        field.clear()
        return self

    def perform_search(self, query):
        (
            self.enter_search_text(query)
            .submit_search()
            .wait_for_search_results()
        )
        return self