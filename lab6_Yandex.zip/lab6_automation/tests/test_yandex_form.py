"""Functional checks for Yandex search."""

import allure
import pytest

from pages.yandex_form_page import YandexFormPage


@allure.suite("Тестирование поиска Яндекс")
@pytest.mark.ui
class TestYandexSearch:
    @pytest.mark.regression
    @pytest.mark.parametrize(
        "search_query,expected_text",
        [
            pytest.param("Selenium WebDriver", "selenium", id="selenium"),
            pytest.param("Python автоматизация тестирования", "python", id="python"),
            pytest.param("Тестирование программного обеспечения", "тестирование", id="testing"),
        ],
    )
    @allure.title("Поиск: {search_query}")
    @allure.description("Проверяет, что поиск открывает выдачу с непустым результатом.")
    def test_search_returns_results(self, browser, base_url, search_query, expected_text):
        page = YandexFormPage(browser)
        with allure.step("Открыть главную страницу Яндекса"):
            page.open_page(base_url)
        with allure.step(f"Выполнить поиск: {search_query}"):
            page.perform_search(search_query)
        with allure.step("Проверить содержимое выдачи"):
            first_result = page.get_first_result_text()
            assert first_result, "Первый результат поиска пуст"
            assert expected_text.casefold() in first_result.casefold(), (
                f"В первом результате не найдено '{expected_text}': {first_result!r}"
            )

    @pytest.mark.smoke
    @allure.title("Поле поиска очищается")
    def test_search_input_can_be_cleared(self, browser, base_url):
        page = YandexFormPage(browser).open_page(base_url)
        with allure.step("Ввести текст и очистить поле поиска"):
            page.enter_search_text("текст для очистки").clear_search_field()
        with allure.step("Проверить, что поле пустое"):
            assert page.get_search_value() == ""

    @pytest.mark.regression
    @allure.title("Подсказки появляются при вводе запроса")
    def test_suggest_display(self, browser, base_url):
        page = YandexFormPage(browser).open_page(base_url)
        with allure.step("Ввести запрос в строку поиска"):
            page.enter_search_text("автоматизация тестирования")
        with allure.step("Дождаться появления списка подсказок"):
            page.wait_for_suggest()
