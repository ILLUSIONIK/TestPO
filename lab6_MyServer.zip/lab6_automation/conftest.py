"""Shared pytest fixtures and failure screenshots."""

import os
from pathlib import Path

import pytest
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from local_server import start_background_server


@pytest.fixture
def browser():
    options = Options()
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--window-size=1920,1080")
    options.add_argument("--disable-notifications")
    if os.getenv("HEADLESS", "1").lower() not in {"0", "false", "no"}:
        options.add_argument("--headless=new")
    binary = os.getenv("CHROME_BINARY")
    if binary:
        options.binary_location = binary

    driver = webdriver.Chrome(options=options)  # Selenium Manager resolves the driver.
    driver.implicitly_wait(0)  # Explicit waits are used in Page Objects.
    yield driver
    driver.quit()


@pytest.fixture(scope="session")
def base_url():
    url, stop_server = start_background_server()
    yield url
    stop_server()


def pytest_runtest_makereport(item, call):
    """Attach and save one screenshot for every completed UI test."""
    if call.when != "call":
        return
    driver = item.funcargs.get("browser")
    if not driver:
        return
    status = "failed" if call.excinfo is not None else "passed"
    try:
        screenshot = driver.get_screenshot_as_png()
        output_dir = Path("screenshots")
        output_dir.mkdir(exist_ok=True)
        safe_name = "".join(ch if ch.isalnum() or ch in "-_." else "_" for ch in item.name)
        (output_dir / f"{status}-{safe_name}.png").write_bytes(screenshot)
        try:
            import allure
            allure.attach(
                screenshot,
                name=f"{status}-{item.name}",
                attachment_type=allure.attachment_type.PNG,
            )
        except Exception:
            pass
    except Exception:
        # A screenshot must not hide the original test failure.
        pass
