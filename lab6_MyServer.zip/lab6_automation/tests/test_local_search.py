"""Functional checks for the local search form."""

import allure
import pytest

from pages.local_search_page import LocalSearchPage


@allure.suite("Тестирование локальной поисковой формы")
@pytest.mark.ui
class TestLocalSearch:
    @pytest.mark.regression
    @pytest.mark.parametrize(
        "search_query,expected_text",
        [
            pytest.param("Selenium WebDriver", "selenium", id="selenium"),
            pytest.param("Python автоматизация тестирования", "python", id="python"),
            pytest.param(
                "Тестирование программного обеспечения", "тестирование", id="testing"
            ),
        ],
    )
    @allure.title("Локальный поиск: {search_query}")
    @allure.description("Проверяет отправку формы и ожидаемый текст результата.")
    def test_search_returns_expected_result(
        self, browser, base_url, search_query, expected_text
    ):
        page = LocalSearchPage(browser)
        with allure.step("Открыть локальную страницу поиска"):
            page.open_page(base_url)
        with allure.step(f"Отправить запрос: {search_query}"):
            page.perform_search(search_query)
        with allure.step("Проверить текст результата"):
            first_result = page.get_first_result_text()
            assert expected_text.casefold() in first_result.casefold(), (
                f"Ожидаемый текст '{expected_text}' не найден: {first_result!r}"
            )

    @pytest.mark.smoke
    @allure.title("Поле поиска очищается")
    def test_search_input_can_be_cleared(self, browser, base_url):
        page = LocalSearchPage(browser).open_page(base_url)
        with allure.step("Ввести текст и очистить поле"):
            page.enter_search_text("текст для очистки").clear_search_field()
        with allure.step("Проверить, что поле пустое"):
            assert page.get_search_value() == ""

    @pytest.mark.regression
    @allure.title("Подсказки появляются при вводе запроса")
    def test_suggest_display(self, browser, base_url):
        page = LocalSearchPage(browser).open_page(base_url)
        with allure.step("Ввести запрос"):
            page.enter_search_text("автоматизация тестирования")
        with allure.step("Проверить появление списка подсказок"):
            page.wait_for_suggest()
