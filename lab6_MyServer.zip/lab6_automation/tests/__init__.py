"""Automated UI tests."""
