"""A tiny local search-form server used by the Selenium tests."""

from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from html import escape
from threading import Thread
from urllib.parse import parse_qs, urlparse


SEARCH_RESULTS = {
    "selenium webdriver": "Selenium WebDriver — инструмент автоматизации браузера.",
    "python автоматизация тестирования": "Python помогает автоматизировать тестирование.",
    "тестирование программного обеспечения": (
        "Тестирование программного обеспечения помогает проверять качество программы."
    ),
}

SUGGESTIONS = [
    "Selenium WebDriver",
    "Python автоматизация тестирования",
    "Тестирование программного обеспечения",
]


def render_page(query="", result=""):
    query_html = escape(query, quote=True)
    result_html = (
        f'<div class="serp-item">{escape(result)}</div>' if result else ""
    )
    return f"""<!doctype html>
<html lang="ru">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Локальная поисковая форма</title>
  <style>
    body {{ font: 16px Arial, sans-serif; max-width: 760px; margin: 48px auto; padding: 0 20px; }}
    form {{ display: flex; gap: 8px; }}
    input {{ flex: 1; padding: 12px; font-size: 16px; }}
    button {{ padding: 0 20px; }}
    .mini-suggest__popup-content {{ border: 1px solid #aaa; padding: 8px; margin-top: 4px; }}
    .suggestion {{ padding: 6px; }}
    .serp-item {{ margin-top: 24px; padding: 16px; border: 1px solid #ddd; }}
  </style>
</head>
<body>
  <h1>Поиск</h1>
  <form action="/search" method="get">
    <input id="text" name="q" value="{query_html}" autocomplete="off" aria-label="Поисковый запрос">
    <button type="submit">Найти</button>
  </form>
  <div class="mini-suggest__popup-content" role="listbox" hidden></div>
  <div id="search-result">{result_html}</div>
  <script>
    const input = document.querySelector('#text');
    const popup = document.querySelector('.mini-suggest__popup-content');
    const suggestions = {SUGGESTIONS!r};
    input.addEventListener('input', () => {{
      const value = input.value.trim().toLocaleLowerCase();
      const matches = suggestions.filter(item => item.toLocaleLowerCase().includes(value));
      popup.innerHTML = matches.map(item => `<div class="suggestion">${{item}}</div>`).join('');
      popup.hidden = value.length === 0 || matches.length === 0;
    }});
  </script>
</body>
</html>"""


class LocalSearchHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        parsed = urlparse(self.path)
        query = parse_qs(parsed.query).get("q", [""])[0]
        result = ""
        if parsed.path == "/search":
            result = SEARCH_RESULTS.get(
                query.strip().casefold(),
                f"По вашему запросу «{query}» найдены локальные результаты.",
            )
        elif parsed.path == "/favicon.ico":
            self.send_response(204)
            self.end_headers()
            return
        elif parsed.path != "/":
            body = "Страница не найдена".encode("utf-8")
            self.send_response(404)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return

        body = render_page(query=query, result=result).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, _format, *_args):
        """Keep test output focused on pytest results."""


def create_server(port=0):
    """Create the server; port=0 asks Windows/Linux to select a free port."""
    return ThreadingHTTPServer(("127.0.0.1", port), LocalSearchHandler)


def run_server(port=8000):
    """Run the local page directly for manual inspection."""
    server = create_server(port)
    print(f"Локальная форма доступна: http://{server.server_address[0]}:{server.server_address[1]}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nСервер остановлен.")
    finally:
        server.server_close()


def start_background_server():
    """Start an ephemeral local server and return its URL and shutdown callback."""
    server = create_server()
    thread = Thread(target=server.serve_forever, daemon=True)
    thread.start()
    host, port = server.server_address

    def stop():
        server.shutdown()
        server.server_close()
        thread.join(timeout=2)

    return f"http://{host}:{port}", stop


if __name__ == "__main__":
    run_server()
