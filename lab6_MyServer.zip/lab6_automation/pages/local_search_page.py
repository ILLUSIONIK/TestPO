"""Page Object for the local search form."""

from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait


class LocalSearchPage:
    SEARCH_INPUT = (By.ID, "text")
    SEARCH_RESULTS = (By.CSS_SELECTOR, "#search-result .serp-item")
    FIRST_RESULT = (By.CSS_SELECTOR, "#search-result .serp-item")
    SUGGESTIONS = (By.CSS_SELECTOR, ".mini-suggest__popup-content")

    def __init__(self, driver, timeout=10):
        self.driver = driver
        self.wait = WebDriverWait(driver, timeout)

    def open_page(self, url):
        self.driver.get(url)
        self.wait.until(EC.presence_of_element_located(self.SEARCH_INPUT))
        return self

    def enter_search_text(self, text):
        field = self.wait.until(EC.element_to_be_clickable(self.SEARCH_INPUT))
        field.clear()
        field.send_keys(text)
        return self

    def wait_for_suggest(self):
        self.wait.until(EC.visibility_of_element_located(self.SUGGESTIONS))
        return self

    def submit_search(self):
        field = self.wait.until(EC.element_to_be_clickable(self.SEARCH_INPUT))
        field.send_keys(Keys.ENTER)
        return self

    def wait_for_search_results(self):
        self.wait.until(EC.visibility_of_element_located(self.SEARCH_RESULTS))
        return self

    def get_first_result_text(self):
        result = self.wait.until(EC.visibility_of_element_located(self.FIRST_RESULT))
        return result.text.strip()

    def get_search_value(self):
        field = self.wait.until(EC.presence_of_element_located(self.SEARCH_INPUT))
        return field.get_attribute("value") or ""

    def clear_search_field(self):
        field = self.wait.until(EC.element_to_be_clickable(self.SEARCH_INPUT))
        field.clear()
        return self

    def perform_search(self, query):
        self.enter_search_text(query).submit_search().wait_for_search_results()
        return self
