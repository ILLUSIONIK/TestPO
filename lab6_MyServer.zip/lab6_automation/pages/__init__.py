"""Page objects for the Yandex UI tests."""
