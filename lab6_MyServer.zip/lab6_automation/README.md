# Лабораторная работа № 6

UI-тестирование поисковой формы с Selenium WebDriver, pytest, Page Object Model и Allure. Для стабильного запуска используется собственная локальная тестовая страница: реальный Яндекс показывает SmartCaptcha при автоматических запросах.

## Что проверяется

- отправка трёх поисковых запросов и ожидаемый текст результата;
- появление подсказок при вводе;
- очистка поля поиска;
- PNG-скриншот каждого UI-теста (успешного и упавшего) в `screenshots/` и вложение в Allure.

## Структура проекта

```text
lab6_automation/
├── pages/local_search_page.py   # Page Object: локаторы и действия
├── tests/test_local_search.py   # пять сценариев pytest
├── local_server.py              # локальная HTML-форма и HTTP-обработчик
├── conftest.py                  # браузер и серверные фикстуры
├── pytest.ini                   # маркеры pytest
└── requirements.txt             # зависимости
```

## Установка в Windows PowerShell

Открой терминал в этой папке и выполни:

```powershell
py -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

Повторно создавать `.venv`, если она уже есть, не нужно.

## Запуск тестов

Проверить обнаружение тестов:

```powershell
.\.venv\Scripts\python.exe -m pytest --collect-only -q
```

В проекте должно обнаружиться 5 сценариев. Выполнить их и собрать данные Allure:

```powershell
.\.venv\Scripts\python.exe -m pytest tests/test_local_search.py -v --alluredir=allure-results
```

Локальный сервер автоматически поднимется на свободном порту перед тестами и остановится после них. Для параллельного запуска:

```powershell
.\.venv\Scripts\python.exe -m pytest tests/test_local_search.py -n 2 -v
```

## Посмотреть страницу вручную

В отдельном терминале запусти:

```powershell
.\.venv\Scripts\python.exe local_server.py
```

Открой адрес `http://127.0.0.1:8000`. Останови сервер сочетанием `Ctrl+C`. Ручной запуск для pytest не требуется.

## Allure

`allure-pytest` формирует данные в `allure-results`. Для просмотра HTML-отчёта нужна отдельная установка Allure Commandline:

```powershell
allure serve allure-results
```

## Важно для защиты

В приложенном задании и примере указан Яндекс. Этот проект проверяет ту же форму поиска на локальной странице, потому что Яндекс блокирует автоматические обращения CAPTCHA. Перед сдачей покажи преподавателю эту причину и уточни, принимает ли он локальный тестовый сервер как замену внешнему сайту. Код локальной страницы можно запустить и открыть отдельно командой выше.
